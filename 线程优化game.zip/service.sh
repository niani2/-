wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 9
	done
}
wait_sys_boot_completed
cd ${0%/*}
nohup ./AppOpt >/dev/null 2>&1 &
sleep 30
echo "$(cat /sys/devices/system/cpu/present)" >/dev/cpuset/background/cpus
